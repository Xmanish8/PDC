<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Simple JSP Page</title>
</head>
<body>
    <h1>Welcome to JSP!</h1>
    <p>This is a simple message displayed using JSP.</p>
</body>
</html>